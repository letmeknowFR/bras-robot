#pragma once 
#include <Arduino.h>

extern byte LobotCheckSum();
void LobotSerialServoMove(HardwareSerial &SerialX, uint8_t id, int16_t position, uint16_t time);
void LobotSerialServoSetID(HardwareSerial &SerialX, uint8_t oldID, uint8_t newID);
